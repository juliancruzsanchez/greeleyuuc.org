/*global uua_services_admin_meta_boxes */
jQuery( function ( $ ) {
	$( '#datetime' ).datetimepicker({
		format: 'd-m-Y ' + uua_services_admin_meta_boxes.time_format,
		formatTime: uua_services_admin_meta_boxes.time_format,
		step: 15,
		validateOnBlur: false, // otherwise, this will reset PM to AM onblur
		defaultTime: uua_services_admin_meta_boxes.default_time,
	});
});
