<?php
/**
 * Plugin Name: UUA Services
 * Plugin URI: https://www.uua.org/communications/websites/wordpress-theme/documentation/technical/services-plugin
 * Description: Services management for the UUA Theme.
 * Version: 1.1.1
 * Author: UUA
 * Author URI: https://www.uua.org
 *
 * Text Domain: uua-services
 *
 * Requires at least: 4.1
 * Tested up to: 5.2
 *
 * License: GNU General Public License v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

defined( 'ABSPATH' ) || exit;

// Define UUAS_PLUGIN_FILE.
if ( ! defined( 'UUAS_PLUGIN_FILE' ) ) {
	define( 'UUAS_PLUGIN_FILE', __FILE__ );
}

/**
 * Check for plugin updates.
 *
 * This will be periodically sending data to Kernl to check for security
 * and feature updates, and verify the validity of your license.
 */
require_once 'plugin_update_check.php';
$uua_services_updater = new PluginUpdateChecker_2_0 (
	'https://kernl.us/api/v1/updates/598fa816467eeb2753820bbf/',
	__FILE__,
	'uua-services',
	1
);

/**
 * Include required core files used in admin and on the frontend.
 */
include_once 'includes/class-uua-post-types.php';
include_once 'includes/class-uua-install.php';
include_once 'includes/class-uua-query.php';
include_once 'includes/uua-core-functions.php';
include_once 'includes/shortcodes/class-uua-shortcode-services.php';

/**
 * Include any classes we need within admin.
 */
if ( is_admin() ) {
	include_once 'includes/admin/class-uua-admin-list-table-services.php';
	include_once 'includes/admin/class-uua-meta-box-service-date.php';
}
