<?php
/**
 * Post Types
 *
 * Registers post types and taxonomies.
 *
 * @package UUA_Services/Classes
 * @version 1.1.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Post types Class.
 */
class UUA_Services_PostTypes {

	/**
	 * Hook in methods.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_taxonomies' ), 5 );
		add_action( 'init', array( __CLASS__, 'register_post_types' ), 5 );
		add_filter( 'jetpack_copy_post_post_types', array( __CLASS__, 'support_jetpack_copy_post' ) );
		register_activation_hook( __FILE__, 'flush_rewrite_rules' );
	}

	/**
	 * Register core taxonomies.
	 */
	public static function register_taxonomies() {

		if ( ! is_blog_installed() ) {
			return;
		}

		do_action( 'uua_services_register_taxonomy' );

		register_taxonomy(
			'uu_service_speaker',
			apply_filters( 'uua_services_taxonomy_objects_service_speaker', array( 'uu_services' ) ),
			apply_filters(
				'uua_services_taxonomy_args_service_speaker', array(
					'hierarchical'          => false,
					'label'                 => __( 'Speakers', 'uua-services' ),
					'labels'                => array(
						'name'                       => __( 'Speakers', 'uua-services' ),
						'singular_name'              => __( 'Speaker', 'uua-services' ),
						'menu_name'                  => _x( 'Speakers', 'Admin menu name', 'uua-services' ),
						'search_items'               => __( 'Search speakers', 'uua-services' ),
						'all_items'                  => __( 'All speakers', 'uua-services' ),
						'edit_item'                  => __( 'Edit speaker', 'uua-services' ),
						'update_item'                => __( 'Update speaker', 'uua-services' ),
						'add_new_item'               => __( 'Add new speaker', 'uua-services' ),
						'new_item_name'              => __( 'New speaker name', 'uua-services' ),
						'popular_items'              => __( 'Popular speakers', 'uua-services' ),
						'separate_items_with_commas' => __( 'Separate speakers with commas', 'uua-services' ),
						'add_or_remove_items'        => __( 'Add or remove speakers', 'uua-services' ),
						'choose_from_most_used'      => __( 'Choose from the most used speakers', 'uua-services' ),
						'not_found'                  => __( 'No speakers found', 'uua-services' ),
					),
					'show_ui'               => true,
					'show_in_rest'          => true,
					'show_admin_column'     => true,
					'query_var'             => true,
					'rewrite'               => array( 'slug' => 'speaker' ),
				)
			)
		);

		register_taxonomy(
			'uu_service_topics',
			apply_filters( 'uua_services_taxonomy_objects_service_topics', array( 'uu_services' ) ),
			apply_filters(
				'uua_services_taxonomy_args_service_topics', array(
					'hierarchical'          => true,
					'label'                 => __( 'Service Topics', 'uua-services' ),
					'labels'                => array(
						'name'              => __( 'Service Topics', 'uua-services' ),
						'singular_name'     => __( 'Topic', 'uua-services' ),
						'menu_name'         => _x( 'Topics', 'Admin menu name', 'uua-services' ),
						'search_items'      => __( 'Search topics', 'uua-services' ),
						'all_items'         => __( 'All topics', 'uua-services' ),
						'parent_item'       => __( 'Parent topic', 'uua-services' ),
						'parent_item_colon' => __( 'Parent topic:', 'uua-services' ),
						'edit_item'         => __( 'Edit topic', 'uua-services' ),
						'update_item'       => __( 'Update topic', 'uua-services' ),
						'add_new_item'      => __( 'Add new topic', 'uua-services' ),
						'new_item_name'     => __( 'New topic name', 'uua-services' ),
						'not_found'         => __( 'No topics found', 'uua-services' ),
					),
					'show_ui'               => true,
					'show_in_rest'          => true,
					'show_admin_column'     => true,
					'query_var'             => true,
					'rewrite'               => array( 'slug' => 'topic' ),
				)
			)
		);

		do_action( 'uua_services_after_register_taxonomy' );
	}

	/**
	 * Register core post types.
	 */
	public static function register_post_types() {
		if ( ! is_blog_installed() || post_type_exists( 'uu_services' ) ) {
			return;
		}

		do_action( 'uua_services_register_post_type' );

		register_post_type( 'uu_services',
			apply_filters( 'uua_services_register_post_type_services',
				array(
					'labels' => array(
							'name'                  => __( 'Services', 'uua-services' ),
							'singular_name'         => __( 'Service', 'uua-services' ),
							'all_items'             => __( 'All Services', 'uua-services' ),
							'menu_name'             => _x( 'Services', 'Admin menu name', 'uua-services' ),
							'add_new'               => __( 'Add New', 'uua-services' ),
							'add_new_item'          => __( 'Add new service', 'uua-services' ),
							'edit'                  => __( 'Edit', 'uua-services' ),
							'edit_item'             => __( 'Edit service', 'uua-services' ),
							'new_item'              => __( 'New service', 'uua-services' ),
							'view_item'             => __( 'View service', 'uua-services' ),
							'view_items'            => __( 'View services', 'uua-services' ),
							'search_items'          => __( 'Search services', 'uua-services' ),
							'not_found'             => __( 'No services found', 'uua-services' ),
							'not_found_in_trash'    => __( 'No services found in trash', 'uua-services' ),
							'parent'                => __( 'Parent service', 'uua-services' ),
							'featured_image'        => __( 'Service image', 'uua-services' ),
							'set_featured_image'    => __( 'Set service image', 'uua-services' ),
							'remove_featured_image' => __( 'Remove service image', 'uua-services' ),
							'use_featured_image'    => __( 'Use as service image', 'uua-services' ),
							'insert_into_item'      => __( 'Insert into service', 'uua-services' ),
							'uploaded_to_this_item' => __( 'Uploaded to this service', 'uua-services' ),
							'filter_items_list'     => __( 'Filter services', 'uua-services' ),
							'items_list_navigation' => __( 'Services navigation', 'uua-services' ),
							'items_list'            => __( 'Services list', 'uua-services' ),
						),
					'public'              => true,
					'show_in_nav_menus'   => false,
					'menu_position'       => 5,
					'menu_icon'           => 'dashicons-megaphone',
					'capability_type'     => 'post',
					'map_meta_cap'        => true,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'supports'            => array( 'title', 'editor', 'author', 'excerpt', 'comments', 'thumbnail', 'revisions', 'custom-fields' ),
					'taxonomies'          => array( 'uu_service_speakers', 'uu_service_topics' ),
					'has_archive'         => true,
					'rewrite'             => array( 'slug' => 'services', 'with_front' => false, 'feeds' => true, ),
					'query_var'           => true,
					'show_in_rest'        => true,
				)
			)
		);

		do_action( 'uua_services_after_register_post_type' );
	}

	/**
	 * Add Service Support to Jetpack Copy Post.
	 *
	 * @param array $post_types Post types supported by default.
	 * @return array
	 */
	public static function support_jetpack_copy_post( $post_types ) {
		$post_types[] = 'uu_services';
		return $post_types;
	}

}

UUA_Services_PostTypes::init();
