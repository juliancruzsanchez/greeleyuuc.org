<?php
/**
 * UUA Services Updates
 *
 * Functions for updating data.
 *
 * @package UUA_Services/Functions
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Update service date for 1.0
 *
 * @return void
 */
function uua_update_100_service_meta() {
	// Only run once
	if ( get_option('uua_services_update_100') ) {
		return;
	}

	$services = new WP_Query( array( 'post_type' => 'uu_services', 'post_status' => 'any', 'posts_per_page' => -1 ) );

	if ( $services->have_posts() ) {
		while ( $services->have_posts() ) {
			$services->the_post();
			update_post_meta( get_the_ID(), '_services_unixtime', get_the_time('U') );
		}
		wp_reset_postdata();
	}

	// log update
	update_option( 'uua_services_update_100', true );
}
