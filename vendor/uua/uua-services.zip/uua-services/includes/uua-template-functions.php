<?php
/**
 * UUA Services Template
 *
 * Functions for the templating system.
 *
 * @package UUA_Services/Functions
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'uua_service_datetime' ) ) :
/**
 * Gets a nicely formatted string for the service date & time.
 */
function uua_service_datetime() {
	$time_string = '<time class="service-date" datetime="%1$s">%2$s</time>';

	$time_string = sprintf( $time_string,
		uua_get_the_service_date( DATE_W3C ),
		uua_get_the_service_date()
	);

	return $time_string;
}
endif;
