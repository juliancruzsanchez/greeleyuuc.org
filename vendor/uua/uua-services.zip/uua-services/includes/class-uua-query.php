<?php
/**
 * Contains the query functions for UUA Services which alter the front-end post queries and loops
 *
 * @package UUA_Services/Classes
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * UUA_Services_Query Class.
 */
class UUA_Services_Query {

	/**
	 * Constructor for the query class. Hooks in methods.
	 */
	public function __construct() {
		if ( ! is_admin() ) {
			add_action( 'pre_get_posts', array( $this, 'pre_get_posts' ) );
		}
	}

	/**
	 * Hook into pre_get_posts to modify the main services query.
	 *
	 * @param WP_Query $q Query instance.
	 */
	public function pre_get_posts( $q ) {

		// We only want to affect the main query.
		if ( ! $q->is_main_query() || 'uu_services' != $q->get( 'post_type' ) && ! $q->is_tax( get_object_taxonomies( 'uu_services' ) ) ) {
			return;
		}

		// Order by 'Service Date'
		if ( ! $q->get( 'orderby') || '_services_unixtime' === $q->get( 'orderby' ) ) {
			$q->set( 'orderby', 'meta_value' );
			$q->set( 'meta_key', '_services_unixtime' );
		}
	}

}

new UUA_Services_Query();
