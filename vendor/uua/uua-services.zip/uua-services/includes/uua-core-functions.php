<?php
/**
 * UUA Services Core Functions
 *
 * General core functions available on both the front-end and admin.
 *
 * @package UUA_Services/Functions
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

// Include core functions (available in both admin and frontend).
require 'uua-template-functions.php';
require 'uua-widget-functions.php';

if ( ! function_exists( 'get_paginated_numbers' ) ) {
	include_once 'pagination-function.php';
}

/**
 * Retrieve the date on which the service is scheduled.
 *
 * @since 1.1.0
 *
 * @param  string      $format Optional. PHP date format defaults to the date_format option if not specified.
 * @param  int|WP_Post $post   Optional. Post ID or WP_Post object. Default current post.
 * @return false|string Date the current service begins. False on failure.
 */
function uua_get_the_service_date( $format = '', $post = null ) {
	$post = get_post( $post );

	if ( ! $post ) {
		return false;
	}

	if ( empty( $format ) ) {
		$format = get_option( 'date_format' ) . ' \a\t ' . get_option( 'time_format' );
	}

	if ( empty( $service_date = get_post_meta( $post->ID, '_uu_services_datetime', true ) ) ) {
		// Fallback to the unix date, for services created before v1.0 - may be removed in future versions.
		if ( empty( $service_date = get_post_meta( $post->ID, '_services_unixtime', true ) ) ) {
			return false;
		}
		$service_date = date( 'Y-m-d H:i:s', $service_date );
	}

	if ( $display_time = get_post_meta( $post->ID, '_uu_services_datetime-display', true ) ) {
		$the_date = esc_html( $display_time );
	} else {
		$the_date = mysql2date( $format, $service_date );
	}

	return $the_date;
}

/**
 * Switch the post date to the service datetime.
 *
 * @param string      $the_date The formatted date.
 * @param string      $d        PHP date format. Defaults to 'date_format' option
 *                              if not specified.
 * @param int|WP_Post $post     The post object or ID.
 * @return string
 */
function uua_services_rewrite_the_date( $the_date, $d, $post ) {
	if ( ! is_admin() && 'uu_services' === $post->post_type ) {
		return uua_get_the_service_date( $d, $post );
	}
	return $the_date;
}
add_filter( 'get_the_date', 'uua_services_rewrite_the_date', 10, 3 );
