<?php
/**
 * Installation related functions and actions.
 *
 * @package UUA_Services/Classes
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * UUA_Services_Install Class.
 */
class UUA_Services_Install {

	/**
	 * UUA Services version.
	 *
	 * @var string
	 */
	public static $version = '1.1.1';

	/**
	 * DB updates and callbacks that need to be run per version.
	 *
	 * @var array
	 */
	private static $db_updates = array(
		'1.0.0' => array(
			'uua_update_100_service_meta',
		),
	);

	/**
	 * Hook in tabs.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'check_version' ), 5 );
		add_action( 'init', array( __CLASS__, 'init_background_updater' ), 5 );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'plugin_row_meta' ), 5, 2 );
	}

	/**
	 * Init background updates
	 */
	public static function init_background_updater() {
		include_once dirname( __FILE__ ) . '/uua-update-functions.php';
		uua_update_100_service_meta();
	}

	/**
	 * Check UUA Services version and run the updater if required.
	 *
	 * This check is done on all requests and runs if the versions do not match.
	 */
	public static function check_version() {
		if ( ! defined( 'IFRAME_REQUEST' ) && version_compare( get_option( 'uua_services_version' ), self::$version, '<' ) ) {
			self::install();
			do_action( 'uua_services_updated' );
		}
	}

	/**
	 * Install.
	 */
	public static function install() {
		if ( ! is_blog_installed() ) {
			return;
		}

		// Check if we are not already running this routine.
		if ( 'yes' === get_transient( 'uuas_installing' ) ) {
			return;
		}

		// If we made it till here nothing is running yet, lets set the transient now.
		set_transient( 'uuas_installing', 'yes', MINUTE_IN_SECONDS * 10 );

		update_option( 'uua_services_version', self::$version );

		delete_transient( 'uuas_installing' );

		do_action( 'uua_services_installed' );
	}

	/**
	 * Show row meta on the plugin screen.
	 *
	 * @param   mixed $links Plugin Row Meta.
	 * @param   mixed $file  Plugin Base file.
	 * @return  array
	 */
	public static function plugin_row_meta( $links, $file ) {
		if ( plugin_basename( UUAS_PLUGIN_FILE ) === $file ) {
			$row_meta = array(
				'support' => '<a href="' . esc_url( apply_filters( 'uua_services_support_url', 'https://www.uua.org/communications/websites/forum' ) ) . '" aria-label="' . esc_attr__( 'Visit the UUA support forum', 'uua-services' ) . '">' . esc_html__( 'Visit support forum', 'uua-services' ) . '</a>',
			);

			return array_merge( $links, $row_meta );
		}

		return (array) $links;
	}

}

UUA_Services_Install::init();
