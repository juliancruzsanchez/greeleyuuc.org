<?php
/**
 * UUA Widget Functions
 *
 * Widget related functions and widget registration.
 *
 * @package UUA_Services/Functions
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

// Include widget classes.
require_once 'widgets/class-uua-widget-featured-service.php';
require_once 'widgets/class-uua-widget-upcoming-services.php';

/**
 * Register Widgets.
 *
 * @since 1.1.0
 */
function uua_services_register_widgets() {
	register_widget( 'upcomingservice_widget' );
	register_widget( 'upcoming_service_list_widget' );
}
add_action( 'widgets_init', 'uua_services_register_widgets' );
