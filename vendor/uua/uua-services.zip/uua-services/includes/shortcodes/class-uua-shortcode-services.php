<?php
/**
 * Services Shortcode
 *
 * @package UUA_Services/Shortcodes
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Services shortcode class.
 */
class UUA_Shortcode_Services {

	/**
	 * Parse query args.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return array
	 */
	protected static function parse_query_args( $atts ) {
		$query_args = array(
			'post_type'      => 'uu_services',
			'meta_key'       => '_services_unixtime',
			'orderby'        => 'meta_value',
			'order'          => ( $atts['order'] ) ? esc_html( $atts['order'] ) : 'ASC',
			'posts_per_page' => ( $atts['limit'] ) ? intval( $atts['limit'] ) : 15,
			'paged'          => ( get_query_var('paged') ) ? get_query_var('paged') : 1,
		);

		if ( 'archive' === $atts['type'] ) {

			// get past services
			$query_args['meta_query'] = array(
				array(
					'key'     => '_services_unixtime',
					'compare' => '<=',
					'value'   => current_time('timestamp'),
				),
			);
			$query_args['order'] = ( $atts['order'] ) ? esc_html( $atts['order'] ) : 'DESC';
		}
		else {

			// get upcoming services
			$query_args['meta_query'] = array(
				array(
					'key'     => '_services_unixtime',
					'compare' => '>=',
					'value'   => current_time('timestamp'),
				),
			);
		}

		return apply_filters( 'uua_shortcode_services_query', $query_args, $atts );
	}

	/**
	 * Output the shortcode.
	 *
	 * @param array $atts Shortcode attributes.
	 */
	public static function output( $atts ) {
		$output = '';

		$atts = shortcode_atts(
			array(
				'type'     => 'upcoming',
				'speakers' => null,
				'topics'   => null,
				'order'    => null,
				'limit'    => null,
			),
			$atts
		);

		$query_args = self::parse_query_args( $atts );

		$services = new WP_Query( $query_args );

		// the service loop
		if ( $services->have_posts() ) {

			$output = '<div class="uua-services uu-service-list">';

			ob_start();

			$i = 0;
			while ( $services->have_posts() ) : $services->the_post(); $i++; ?>

				<?php if ( 'archive' === $atts['type'] && ( $i > 3 || get_query_var('paged') > 1 ) ) : ?>

				<article <?php post_class( 'service-archive-list' ); ?>>
					<div class="entry-content small">
						<span class="service-title"><a href="<?php the_permalink(); ?>"><strong><?php the_title(); ?></strong></a></span>
						<div class="entrymeta">
							<?php
							echo uua_service_datetime();

							// Service Speaker(s)
							echo get_the_term_list(
								get_the_ID(),
								'uu_service_speaker',
								'<span class="speaker">',
								', ',
								'</span>'
							);
							?>
						</div>
					</div>
				</article>

				<?php else : ?>

				<article <?php post_class( 'featured' ); ?>>
					<p class="small service-meta"><?php echo uua_service_datetime(); ?></p>
					<div class="entry-content">
						<a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
						<div class="entrymeta">
							<?php
							// Service Speaker(s)
							echo get_the_term_list(
								get_the_ID(),
								'uu_service_speaker',
								'<span class="speaker">',
								', ',
								'</span>'
							);
							?>
						</div>
						<?php the_excerpt(); ?>
					</div>
				</article>

				<?php endif; ?>

			<?php endwhile;

			// Pagination
			if ( function_exists( 'get_paginated_numbers' ) ) {
				echo get_paginated_numbers( array( 'query' => $services ) );
			}

			$output .= ob_get_clean();

			$output .= '</div>';

		}
		wp_reset_postdata();

		return $output;
	}

}

add_shortcode( apply_filters( 'uua_services_shortcode_tag', 'uua_services' ), array( 'UUA_Shortcode_Services', 'output' ) );

/**
 * Deprecated. [upcoming-services] shortcode.
 *
 * @deprecated 1.1.0 Use [uua_services] instead.
 */
add_shortcode( 'upcoming-services', array( 'UUA_Shortcode_Services', 'output' ) );

/**
 * Deprecated. [service-archive] shortcode.
 *
 * @deprecated 1.1.0 Use [uua_services type="archive"] instead.
 */
function uua_services_archive_shortcode() {
	return do_shortcode( '[uua_services type="archive"]' );
}
add_shortcode( 'service-archive', 'uua_services_archive_shortcode' );
