<?php
/**
 * Service Date.
 *
 * Display the service date and time meta box.
 *
 * @package UUA_Services/Admin/Meta Boxes
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * UUA_Meta_Box_Service_Date Class.
 */
class UUA_Meta_Box_Service_Date {

	/**
	 * Meta box fields.
	 *
	 * @var array
	 */
	protected $fields;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->fields = array(
			array(
				'id'           => 'datetime',
				'label'        => __( 'Service Date and Time', 'uua-services' ),
				'type'         => 'datetime',
				'show_in_rest' => false,
			),
			array(
				'id'           => 'datetime-display',
				'label'        => __( 'Display Date and Time', 'uua-services' ),
				'type'         => 'text',
				'show_in_rest' => true,
			),
		);

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'save_meta_boxes' ), 1, 2 );

		// REST API
		add_action( 'init', array( $this, 'register_meta_keys' ) );
		add_filter( 'rest_uu_services_query', array( $this, 'default_rest_query' ), 10, 2 );
	}

	/**
	 * Enqueue scripts.
	 */
	public function enqueue_admin_scripts() {
		$screen = get_current_screen();
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		if ( 'uu_services' === $screen->post_type ) {

			// jQuery Plugin Date and Time Picker
			// @link https://github.com/xdan/datetimepicker
			wp_enqueue_style( 'jquery-datetimepicker-style', plugin_dir_url( UUAS_PLUGIN_FILE ) . 'assets/js/jquery-datetimepicker/jquery.datetimepicker.min.css', array(), '2.5.20' );
			wp_enqueue_script( 'jquery-datetimepicker', plugin_dir_url( UUAS_PLUGIN_FILE ) . 'assets/js/jquery-datetimepicker/jquery.datetimepicker.full.min.js', array( 'jquery' ), '2.5.20' );

			// Meta boxes script
			wp_enqueue_script( 'uua-services-admin-meta-boxes', plugin_dir_url( UUAS_PLUGIN_FILE ) . 'assets/js/admin/meta-boxes' . $suffix . '.js', array( 'jquery', 'jquery-datetimepicker' ), '1.0.4' );

			$params = array(
				'time_format'  => get_option( 'time_format', 'g:i a' ),
				'default_time' => '10:30',
			);

			wp_localize_script( 'uua-services-admin-meta-boxes', 'uua_services_admin_meta_boxes', $params );
		}
	}

	/**
	 * Register meta keys.
	 */
	public function register_meta_keys() {

		// Display date and time
		register_meta( 'post', '_uu_services_datetime-display', array(
			'show_in_rest' => true,
			)
		);

		// Unix datetime
		register_meta( 'post', '_services_unixtime', array(
			'show_in_rest' => true,
			)
		);

	}

	/**
	 * Modify the query object for the 'Services' REST API.
	 *
	 * Sort by 'Service Date'.
	 *
	 * @param array           $args  Key value array of query var to query value.
	 * @param WP_REST_Request $query The request used.
	 * @return void
	 */
	public function default_rest_query( $args, $query ) {
		$args['orderby']  = 'meta_value';
		$args['meta_key'] = '_services_unixtime';

		if ( isset( $_GET['after'] ) ) {
			unset( $args['date_query'] );
			$args['meta_query'] = array(
				array(
					'key'     => $args['meta_key'],
					'value'   => strtotime( $_GET['after'] ),
					'compare' => '>',
				),
			);
		}
		return $args;
	}

	/**
	 * Add Meta boxes.
	 */
	public function add_meta_boxes() {
		add_meta_box( 'service-date-and-time', __( 'Service Date and Time', 'uua-services' ), array( $this, 'output' ), 'uu_services', 'side', 'high' );
	}

	/**
	 * Output the meta box.
	 *
	 * @param WP_Post $post
	 */
	public function output( $post ) {
		wp_nonce_field( 'uua_service_save_data', 'uua_service_meta_nonce' );

		foreach ( $this->fields as $field ) {
			$label = '<label for="' . $field['id'] . '">' . $field['label'] . '</label>';
			$db_value = get_post_meta( $post->ID, '_uu_services_' . $field['id'], true );
			switch ( $field['type'] ) {
				default:
					$input = sprintf(
						'<input id="%s" name="%s" type="%s" value="%s" placeholder="%s">',
						$field['id'],
						$field['id'],
						$field['type'],
						$db_value,
						$db_value
					);
			}
			echo '<p>' . $label . '<br>' . $input . '</p>';
		}
	}

	/**
	 * Check if we're saving, then trigger an action based on the post type.
	 *
	 * @param  int    $post_id
	 * @param  object $post
	 */
	public function save_meta_boxes( $post_id, $post ) {
		// $post_id and $post are required
		if ( empty( $post_id ) || empty( $post ) ) {
			return;
		}

		// Dont' save meta boxes for revisions or autosaves
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || is_int( wp_is_post_revision( $post ) ) || is_int( wp_is_post_autosave( $post ) ) ) {
			return;
		}

		// Check the nonce
		if ( empty( $_POST['uua_service_meta_nonce'] ) || ! wp_verify_nonce( $_POST['uua_service_meta_nonce'], 'uua_service_save_data' ) ) {
			return;
		}

		// Check the post being saved == the $post_id to prevent triggering this call for other save_post events
		if ( empty( $_POST['post_ID'] ) || $_POST['post_ID'] != $post_id ) {
			return;
		}

		// Check user has permission to edit
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Check the post type
		if ( in_array( $post->post_type, array( 'uu_services' ) ) ) {
			foreach ( $this->fields as $field ) {
				if ( isset( $_POST[ $field['id'] ] ) ) {

					// Save field data
					update_post_meta( $post_id, '_uu_services_' . $field['id'], sanitize_text_field( $_POST[ $field['id'] ] ) );

					// Save entered date/time as unix date
					if ( 'datetime' == $field['id'] ) {
						$unix_date = strtotime( $_POST[ $field['id'] ] );
						update_post_meta( $post_id, '_services_unixtime', $unix_date );
					}
				}
			}
		}
	}
}

new UUA_Meta_Box_Service_Date;
