<?php
/**
 * List tables: services.
 *
 * @package UUA_Services/Admin
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * UUA_Admin_List_Table_Services Class.
 */
class UUA_Admin_List_Table_Services {

	/**
	 * Post type.
	 *
	 * @var string
	 */
	protected $list_table_type = 'uu_services';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'default_hidden_columns', array( $this, 'define_hidden_columns' ), 10, 2 );
		add_filter( 'manage_edit-' . $this->list_table_type . '_sortable_columns', array( $this, 'define_sortable_columns' ) );
		add_filter( 'manage_' . $this->list_table_type . '_posts_columns', array( $this, 'define_columns' ) );
		add_action( 'manage_' . $this->list_table_type . '_posts_custom_column', array( $this, 'render_columns' ), 10, 2 );
		add_action( 'pre_get_posts', array( $this, 'pre_get_posts' ) );
	}

	/**
	 * Define hidden columns.
	 *
	 * @param array     $hidden An array of columns hidden by default.
	 * @param WP_Screen $screen WP_Screen object of the current screen.
	 * @return array
	 */
	public function define_hidden_columns( $hidden, $screen ) {
		if ( $this->list_table_type === $screen->post_type ) {
			$hidden[] = 'date';
		}
		return $hidden;
	}

	/**
	 * Define which columns are sortable.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function define_sortable_columns( $columns ) {
		$custom = array(
			'service_date' => array( '_services_unixtime', 1 ),
		);
		unset( $columns['comments'] );

		return wp_parse_args( $custom, $columns );
	}

	/**
	 * Define which columns to show on this screen.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function define_columns( $columns ) {
		$show_columns                 = array();
		$show_columns['cb']           = $columns['cb'];
		$show_columns['title']        = __( 'Service Title', 'uua-services' );
		$show_columns['service_date'] = __( 'Service Date', 'uua-services' );
		$show_columns['speaker']      = __( 'Speakers', 'uua-services' );
		$show_columns['topic']        = __( 'Topics', 'uua-services' );
		$show_columns['date']         = $columns['date'];

		return $show_columns;
	}

	/**
	 * Render individual columns.
	 *
	 * @param string $column Column ID to render.
	 * @param int    $post_id Post ID being shown.
	 */
	public function render_columns( $column, $post_id ) {
		if ( is_callable( array( $this, 'render_' . $column . '_column' ) ) ) {
			$this->{"render_{$column}_column"}( $post_id );
		}
	}

	/**
	 * Render columm: service_date.
	 */
	protected function render_service_date_column( $post_id ) {

		// Get the service date.
		$format = get_option( 'date_format' ) . ' - ' . get_option( 'time_format' );
		$date = uua_get_the_service_date( $format, $post_id );

		// Display service date, or output a default message.
		if ( ! empty( $date ) ) {
			echo esc_html( $date );
		} else {
			echo __( 'Unknown', 'uua-services' );
		}
	}

	/**
	 * Render columm: speaker.
	 */
	protected function render_speaker_column( $post_id ) {

		// Get the speakers for the post.
		$terms = get_the_terms( $post_id, 'uu_service_speaker' );

		// If terms were found.
		if ( ! empty( $terms ) ) {

			$out = array();

			// Loop through each term, linking to the 'edit posts' page for the specific term.
			foreach ( $terms as $term ) {
				$out[] = sprintf( '<a href="%s">%s</a>',
					esc_url( add_query_arg( array( 'post_type' => 'uu_services', 'uu_service_speaker' => $term->slug ), 'edit.php' ) ),
					esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'uu_service_speaker', 'display' ) )
				);
			}

			// Join the terms, separating them with a comma.
			echo join( ', ', $out );
		}

		// If no terms were found, output a default message.
		else {
			_e( 'No Speakers', 'uua-services' );
		}
	}

	/**
	 * Render columm: topic.
	 */
	protected function render_topic_column( $post_id ) {

		// Get the tpoics for the post.
		$terms = get_the_terms( $post_id, 'uu_service_topics' );

		// If terms were found.
		if ( ! empty( $terms ) ) {

			$out = array();

			// Loop through each term, linking to the 'edit posts' page for the specific term.
			foreach ( $terms as $term ) {
				$out[] = sprintf( '<a href="%s">%s</a>',
					esc_url( add_query_arg( array( 'post_type' => 'uu_services', 'uu_service_topics' => $term->slug ), 'edit.php' ) ),
					esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'uu_service_topics', 'display' ) )
				);
			}

			// Join the terms, separating them with a comma.
			echo join( ', ', $out );
		}

		// If no terms were found, output a default message.
		else {
			_e( 'No Topics', 'uua-services' );
		}
	}

	/**
	 * Hook into pre_get_posts to modify the 'Services' admin list table.
	 *
	 * @param WP_Query $q Query instance.
	 */
	public function pre_get_posts( $q ) {

		// Only run on the Services admin list table
		if ( ! is_admin() || ! $q->is_main_query() || 'uu_services' != $q->get( 'post_type' ) ) {
			return;
		}

		// Order by 'Service Date'
		if ( ! $q->get( 'orderby') || '_services_unixtime' === $q->get( 'orderby' ) ) {
			$q->set( 'orderby', 'meta_value' );
			$q->set( 'meta_key', '_services_unixtime' );
		}
	}

}

new UUA_Admin_List_Table_Services;
