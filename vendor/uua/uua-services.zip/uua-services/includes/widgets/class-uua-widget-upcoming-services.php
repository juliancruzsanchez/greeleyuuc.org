<?php
/**
 * UUA Upcoming Services Widget.
 *
 * @package UUA_Services/Widgets
 * @version 1.1.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Widget UUA Upcoming Services class.
 */
class upcoming_service_list_widget extends WP_Widget {

	const VERSION = '1.1.0';

	/**
	 * Constructor.
	 */
	public function __construct() {
		$args = array(
			'classname'   => 'upcoming_service_list_widget',
			'description' => esc_html__( 'Displays the next upcoming service.', 'uua-services' ),
		);

		parent::__construct(
			'upcoming_service_list_widget',
			esc_html__( 'UUA Upcoming Service', 'uua-services' ),
			$args
		);
	}

	/**
	 * Output widget.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args     Arguments.
	 * @param array $instance Widget instance.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		// Service query args
		$query_args = array(
			'post_type'      => 'uu_services',
			'meta_query'     => array(
				array(
					'key'     => '_services_unixtime',
					'compare' => '>=',
					'value'   => current_time('timestamp'),
				),
			),
			'meta_key'       => '_services_unixtime',
			'orderby'        => 'meta_value',
			'order'          => 'ASC',
			'posts_per_page' => 1,
		);

		/**
		 * Filter the service query arguments.
		 *
		 * @param array $query_args An array of query arguments.
		 * @return array
		 */
		$query_args = apply_filters( 'uua_widget_upcoming_services_query_args', $query_args );

		$upcoming_service = new WP_Query( $query_args );

		// the service loop
		if ( $upcoming_service->have_posts() ) {

			if ( ! empty( $instance['title'] ) ) {
				echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
			}

			echo '<ul>';

			while ( $upcoming_service->have_posts() ) : $upcoming_service->the_post();

				echo '<li>';

					echo '<header><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></header>';

					echo
						'<div class="entrymeta">',
							uua_service_datetime(),
							get_the_term_list(
								get_the_ID(),
								'uu_service_speaker',
								'<span class="speaker">',
								', ',
								'</span>'
							),
						'</div>';

					the_excerpt();

				echo '</li>';

			endwhile;

			echo '</ul>';

		}
		wp_reset_postdata();

		echo $args['after_widget'];
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance[ 'title' ] = strip_tags( $new_instance[ 'title' ] );
		return $instance;
	}

	/**
	 * Outputs the settings update form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Instance.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title', 'uua-services' ); ?>:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

<?php
	}
}
