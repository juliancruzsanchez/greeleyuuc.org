<?php
/**
 * UUA Featured Upcoming Service Widget.
 *
 * @package UUA_Services/Widgets
 * @version 1.1.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Widget UUA Featured Service class.
 */
class upcomingservice_widget extends WP_Widget {

	const VERSION = '1.1.0';

	/**
	 * Constructor.
	 */
	public function __construct() {
		$args = array(
			'classname'   => 'upcomingservice_widget',
			'description' => esc_html__( 'Displays the upcoming service with additional quick links.', 'uua-services' ),
		);

		parent::__construct(
			'upcomingservice_widget',
			esc_html__( 'UUA Featured Upcoming Service', 'uua-services' ),
			$args
		);
	}

	/**
	 * Output widget.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args     Arguments.
	 * @param array $instance Widget instance.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		// Service query args
		$query_args = array(
			'post_type'      => 'uu_services',
			'meta_query'     => array(
				array(
					'key'     => '_services_unixtime',
					'compare' => '>=',
					'value'   => current_time('timestamp'),
				),
			),
			'meta_key'       => '_services_unixtime',
			'orderby'        => 'meta_value',
			'order'          => 'ASC',
			'posts_per_page' => 1,
		);

		/**
		 * Filter the service query arguments.
		 *
		 * @deprecated 1.1.0
		 * @deprecated use the 'uua_widget_featured_service_query_args' filter instead
		 *
		 * @param array $query_args An array of query arguments.
		 * @return array
		 */
		$query_args = apply_filters_deprecated( 'upcomingservice_widget_query_args', array( $query_args ), 'UUA Services 1.1.0', 'uua_widget_featured_service_query_args' );

		$query_args = apply_filters( 'uua_widget_featured_service_query_args', $query_args );

		$upcoming_service = new WP_Query( $query_args );

		// the service loop
		if ( $upcoming_service->have_posts() ) {

			echo '<small>' . esc_html( $instance['title'] ) . '</small>';

			while ( $upcoming_service->have_posts() ) : $upcoming_service->the_post();

				echo '<h3><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></h3>';

				echo
					'<div class="entrymeta">',
						uua_service_datetime(),
						get_the_term_list(
							get_the_ID(),
							'uu_service_speaker',
							'<span class="speaker">',
							', ',
							'</span>'
						),
					'</div>';

				the_excerpt();

			endwhile;
		}
		wp_reset_postdata();

		// featured quick links
		$links = array(
			array(
				'title'   => __( 'First Time Visitor?', 'uua-services' ),
				'url'     => esc_url( $instance['firsttimevisitorlink'] ),
				'classes' => 'fa fa-star',
			),
			array(
				'title'   => __( 'Upcoming Services', 'uua-services' ),
				'url'     => esc_url( $instance['upcomingserviceslink'] ),
				'classes' => 'fa fa-calendar-plus-o',
			),
			array(
				'title'   => __( 'Service Archive', 'uua-services' ),
				'url'     => esc_url( $instance['servicearchivelink'] ),
				'classes' => 'fa fa-list',
			)
		);

		/**
		 * Filter the featured service quick links.
		 *
		 * @param array $links Featured quick link data.
		 * @return array
		 */
		$links = apply_filters( 'uua_widget_featured_service_links', $links, $instance );

		if ( is_array( $links ) ) {
			echo '<ul>';

			foreach ( $links as $link ) {
				if ( empty( $link['url'] ) )
					continue;

				echo '<li><a href="' . $link['url'] . '">' . '<i class="' . $link['classes'] . '"></i><br />' . $link['title'] . '</a></li>';
			}

			echo '</ul>';
		}

		echo $args['after_widget'];
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance[ 'title' ] = strip_tags( $new_instance[ 'title' ] );
		$instance[ 'firsttimevisitorlink' ] = sanitize_text_field( $new_instance[ 'firsttimevisitorlink' ] );
		$instance[ 'upcomingserviceslink' ] = sanitize_text_field( $new_instance[ 'upcomingserviceslink' ] );
		$instance[ 'servicearchivelink' ] = sanitize_text_field( $new_instance[ 'servicearchivelink' ] );
		return $instance;
	}

	/**
	 * Outputs the settings update form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Instance.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$links = array();
		$links[] = ! empty( $instance['firsttimevisitorlink'] ) ? $instance['firsttimevisitorlink'] : '';
		$links[] = ! empty( $instance['upcomingserviceslink'] ) ? $instance['upcomingserviceslink'] : '';
		$links[] = ! empty( $instance['servicearchivelink'] ) ? $instance['servicearchivelink'] : '';
		?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title', 'uua-services' ); ?>:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'firsttimevisitorlink' ); ?>"><?php _e( 'Link 1: First Time Visitor', 'uua-services' ); ?>:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'firsttimevisitorlink' ); ?>" name="<?php echo $this->get_field_name( 'firsttimevisitorlink' ); ?>" type="text" value="<?php echo esc_url( $links[0] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'upcomingserviceslink' ); ?>"><?php _e( 'Link 2: Upcoming Services', 'uua-services' ); ?>:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'upcomingserviceslink' ); ?>" name="<?php echo $this->get_field_name( 'upcomingserviceslink' ); ?>" type="text" value="<?php echo esc_url( $links[1] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'servicearchivelink' ); ?>"><?php _e( 'Link 3: Service Archive', 'uua-services' ); ?>:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'servicearchivelink' ); ?>" name="<?php echo $this->get_field_name( 'servicearchivelink' ); ?>" type="text" value="<?php echo esc_url( $links[2] ); ?>" />
		</p>

<?php
	}
}
