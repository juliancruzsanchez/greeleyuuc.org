UUA Services Plugin
====================

* Documentation: [UUA Services Plugin](https://www.uua.org/communications/websites/wordpress-theme/documentation/technical/services-plugin)
* Comments or Questions: [UUA Website Forum](https://www.uua.org/communications/websites/forum)

- - -

# Shortcodes

The plugin comes with a shortcode that can be used to insert service content inside posts and pages.

## Services

The `[uua_services]` shortcode allows you to display services by type with support for pagination, and sorting, replacing the need for multiples shortcodes such as: `[upcoming-services]` or `[service-archive]`.

### Attributes

The following attributes are available to use in conjunction with the `[uua_services]` shortcode.

| Attribute         | Default       | Description
| ----------------- | ------------- | ----------------------------------------------------
| `type`            | `upcoming`    | Available options are: `upcoming` or `archive`.
| `order`           | `ASC`         | States whether the service ordering is ascending (ASC) or descending (DESC).
| `limit`           | `15`          | The number of services to display.

- - -

# Widgets

Two widgets come with the plugin that help you display service content in the widgetized areas.

* **UUA Featured Upcoming Service** - Display the next upcoming service with additional quick links.
* **UUA Upcoming Service** - Display the next upcoming service.
