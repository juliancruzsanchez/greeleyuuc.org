<?php
/**
 * Additional features to allow styling of the templates
 *
 * @package uuatheme
 * @version 1.1
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function uuatheme_body_class( $classes ) {

	// Adds a class for the selected Site Color Scheme
	$classes[] = get_theme_mod('uuatheme_colors');

	// Adds permalink to posts and pages.
	if ( is_single() || is_page() && ! is_front_page() ) {
		if ( ! in_array( basename( get_permalink() ), $classes ) ) {
			$classes[] = basename( get_permalink() );
		}
	}

	return $classes;
}
add_filter( 'body_class', 'uuatheme_body_class' );

/**
 * Filters the “more” link displayed after a trimmed excerpt.
 *
 * @return string
 */
function uuatheme_excerpt_more() {
	return sprintf( ' &hellip; <a href="%1$s" class="more-link">%2$s</a>',
		esc_url( get_permalink( get_the_ID() ) ),
		sprintf( __( 'Continue reading %s', 'uuatheme' ), '<span class="screen-reader-text">' . get_the_title( get_the_ID() ) . '</span>' )
	);
}
add_filter( 'excerpt_more', 'uuatheme_excerpt_more' );

/**
 * Add Service Topics after single content.
 *
 * @param string $content Content of the current post.
 * @return string
 */
function uuatheme_service_content( $content ) {
	if ( is_singular( 'uu_services' ) ) {
		$topics = get_the_term_list(
			get_the_ID(),
			'uu_service_topics',
			'<p class="small topics">' . __( 'Topics', 'uua-services' ) . ': ',
			', ',
			'</p>'
		);
		return $content . $topics;
	}
	return $content;
}
add_filter( 'the_content', 'uuatheme_service_content' );

/**
 * Hide the testimonial author link.
 *
 * @param string $link HTML link.
 * @return string
 */
function uuatheme_testimonial_author_posts_link( $link ) {
	if ( is_post_type_archive( 'jetpack-testimonial' ) || is_singular( 'jetpack-testimonial' ) ) {
		return '';
	}
	return $link;
}
add_filter( 'the_author_posts_link', 'uuatheme_testimonial_author_posts_link' );

/**
 * Filter the Jetpack Testimonials archive description.
 *
 * @param string $description Archive description to be displayed.
 * @return string
 */
function uuatheme_testimonial_archive_description( $description ) {
	if ( is_post_type_archive( 'jetpack-testimonial' ) ) {
		return __( 'Congregation Testimonials', 'uuatheme' );
	}
	return $description;
}
add_filter( 'get_the_archive_description', 'uuatheme_testimonial_archive_description' );

/**
 * Plugin: MetaSlider
 * @link https://wordpress.org/plugins/ml-slider/
 */
if ( class_exists( 'MetaSliderPlugin' ) ) :

	/**
	 * Add custom MetaSlider theme.
	 *
	 * @param array $themes Silder theme directories.
	 * @return array
	 */
	function uuatheme_metaslider_theme( $themes ) {
		$themes[] = get_template_directory() . '/metaslider';
		return $themes;
	}
	add_filter( 'metaslider_extra_themes', 'uuatheme_metaslider_theme' );

	/**
	 * Set default MetaSlider theme.
	 *
	 * @return string
	 */
	function uuatheme_metaslider_default_theme() {
		return 'uua';
	}
	add_filter( 'metaslider_default_theme', 'uuatheme_metaslider_default_theme' );

	/**
	 * Set default MetaSlider parameters.
	 *
	 * @return string
	 */
	function uuatheme_default_parameters( $params ) {
		$slider_parameters = array(
			'height' => 400,
			'delay'  => 4000,
			'effect' => 'slide',
		);
		return array_merge( $params, $slider_parameters );
	}
	add_filter( 'metaslider_default_parameters', 'uuatheme_default_parameters' );

endif;
