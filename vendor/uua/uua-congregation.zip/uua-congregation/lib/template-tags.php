<?php
/**
 * Custom template tags for this theme
 *
 * @package uuatheme
 * @version 1.3
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'get_paginated_numbers' ) ) {
	include_once get_parent_theme_file_path( '/lib/pagination-function.php' );
}

if ( ! function_exists( 'uuatheme_get_notice_content' ) ) :
/**
 * Get site notice content.
 *
 * @return string
 */
function uuatheme_get_notice_content() {
	$content = get_theme_mod( 'uuatheme_notice_content' );
	if ( ! empty( $content ) ) {
		return html_entity_decode( $content );
	}
}
endif;

if ( ! function_exists( 'uuatheme_get_header_text' ) ) :
/**
 * Get header text content.
 *
 * @return string
 */
function uuatheme_get_header_text() {
	$content = get_theme_mod( 'uuatheme_header_text' );
	if ( ! empty( $content ) ) {
		return '<h4>' . $content . '</h4>';
	}
}
endif;

if ( ! function_exists( 'uuatheme_check_for_page_tree' ) ) :
/**
 * Get the top level page ID
 *
 * @return int Page ID
 */
function uuatheme_check_for_page_tree() {
	if ( is_page() ) {
		global $post;

		// next check if the page has parents
		if ( $post->post_parent ){

			// fetch the list of ancestors
			$parents = array_reverse( get_post_ancestors( $post->ID ) );

			// get the top level ancestor
			return $parents[0];
		}

		// return the the topmost ancestor ID or the current page
		return $post->ID;
	}
}
endif;

if ( ! function_exists( 'uuatheme_list_subpages' ) ) :
/**
 * Context sensitive navigation
 *
 * @return void
 */
function uuatheme_list_subpages() {

	if ( is_page() ) {

		// fetch top level page
		$ancestor = uuatheme_check_for_page_tree();

		// set the arguments for children of the ancestor page
		$args = array(
			'child_of' => $ancestor,
			'depth'    => '4',
			'title_li' => '',
		);

		// include private pages for logged-in users
		if ( current_user_can('read_private_pages') ) {
			$args['post_status'] = 'publish,private';
		}

		// set a value for get_pages to check if it's empty
		$list_pages = get_pages( $args );

		// HTML output
		if ( $list_pages ) {

			echo '<ul class="page-tree">';

				// top level ancestor page
				echo
					'<li class="ancestor">',
						'<a href="' . get_permalink( $ancestor ) . '">' . get_the_title( $ancestor ) . '</a>',
					'</li>';

				// list subpages of ancestor or current page
				wp_list_pages( $args );

			echo '</ul>';

		}
	}
}
endif;
