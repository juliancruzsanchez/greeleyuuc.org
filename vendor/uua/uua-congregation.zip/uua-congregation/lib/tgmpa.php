<?php
/**
 * TGM Plugin Activation Settings
 *
 * Require and recommend plugins for the UUA Congregation theme.
 *
 * @see http://tgmpluginactivation.com/configuration/ for detailed documentation.
 *
 * @package    uuatheme
 * @subpackage TGM-Plugin-Activation
 * @version    2.6.1
 */

/**
 * Include the TGM_Plugin_Activation class.
 */
require_once get_parent_theme_file_path( '/inc/tgmpa/class-tgm-plugin-activation.php' );

/**
 * Get 'UUA Services' plugin details.
 */
function uuatheme_services_plugin() {
	$response = wp_remote_get( 'https://kernl.us/api/v1/updates/598fa816467eeb2753820bbf/' );
	return json_decode( wp_remote_retrieve_body( $response ) );
}

/**
 * Register the required plugins for this theme.
 *
 * This function is hooked into tgmpa_init, which is fired within the
 * TGM_Plugin_Activation class constructor.
 */
function uuatheme_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array();

	/*
	 * Recommend the UUA Services plugin.
	 */
	$services_plugin = uuatheme_services_plugin();

	if ( is_object( $services_plugin ) ) {
		$plugins[] = array(
			'name'               => $services_plugin->name,
			'slug'               => $services_plugin->slug,
			'source'             => $services_plugin->download_url,
			'required'           => false, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '1.1.0', // The active plugin must be this version or higher.
			'external_url'       => $services_plugin->homepage,
		);
	}

	/*
	 * Recommend plugins from the WordPress Plugin Repository.
	 */
	array_push( $plugins,
		array(
			'name'        => 'Events Manager',
			'slug'        => 'events-manager',
			'required'    => false,
		),
		array(
			'name'        => 'Jetpack',
			'slug'        => 'jetpack',
			'required'    => false,
		),
		array(
			'name'        => 'List Category Posts',
			'slug'        => 'list-category-posts',
			'required'    => false,
		),
		array(
			'name'        => 'MetaSlider',
			'slug'        => 'ml-slider',
			'required'    => false,
			'version'     => '3.13.0',
			'is_callable' => 'cptbc_post_type',
		),
		array(
			'name'        => 'Site Origin Widgets Bundle',
			'slug'        => 'so-widgets-bundle',
			'required'    => false,
		),
		array(
			'name'        => 'WordPress SEO by Yoast',
			'slug'        => 'wordpress-seo',
			'required'    => false,
			'is_callable' => 'wpseo_init',
		)
	);

	/*
	 * Array of configuration settings.
	 *
	 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
	 * strings available, please help us make TGMPA even better by giving us access to these translations or by
	 * sending in a pull-request with .po file(s) with the translations.
	 *
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id'           => 'uuatheme',              // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.
	);

	tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'uuatheme_register_required_plugins' );
