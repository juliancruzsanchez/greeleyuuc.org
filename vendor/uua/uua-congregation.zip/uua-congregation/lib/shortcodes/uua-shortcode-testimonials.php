<?php
/**
 * UUA Testimonials Shortcode
 *
 * @deprecated 1.3.0
 * @package uuatheme/Shortcodes
 * @since 1.0.0
 * @version 2.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists('uua_testimonials_shortcode') ) :

/**
 * Deprecated. [uua_testimonials] shortcode.
 *
 * @deprecated 1.3.0 Use Jetpack [testimonials] instead.
 */
function uua_testimonials_shortcode() {
	// Deprecated notice
	if ( WP_DEBUG && apply_filters( 'deprecated_function_trigger_error', true ) ) {
		trigger_error( "The [uua_testimonials] shortcode is <strong>deprecated</strong> since UUA Theme version 1.3.0! Use Jetpack's [testimonials] shortcode instead." );
	}

	// Output testimonials
	if ( class_exists( 'Woothemes_Testimonials' ) ) {
		return do_shortcode( '[woothemes_testimonials limit=-1 size=150]' );
	} elseif ( post_type_exists( 'jetpack-testimonial' ) ) {
		return do_shortcode( '[jetpack_testimonials]' );
	}
	return;
}
add_shortcode( 'uua_testimonials', 'uua_testimonials_shortcode' );

endif;

if ( class_exists( 'Woothemes_Testimonials' ) ) :

/**
 * Filters the WooThemes testimonials Read More link text.
 *
 * @param string $more_link_element Read More link element.
 * @param string $more_link_text    Read More text.
 */
function uuatheme_woothemes_testimonials_more_link( $more_link_element, $more_link_text ) {
	global $post;
	if ( 'testimonial' == $post->post_type ) {
		$more_link_element = str_replace( $more_link_text, __( 'Read the full testimonial.', 'uuatheme' ), $more_link_element );
	}
	return $more_link_element;
}
add_filter( 'the_content_more_link', 'uuatheme_woothemes_testimonials_more_link', 10, 2 );

endif;
