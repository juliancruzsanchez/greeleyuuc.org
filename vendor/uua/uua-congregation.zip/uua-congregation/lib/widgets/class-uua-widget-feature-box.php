<?php
/**
 * UUA Feature Box Widget.
 *
 * @package uuatheme/Widgets
 * @version 1.1.1
 */

defined( 'ABSPATH' ) || exit;

/**
 * Widget UUA featured content class.
 */
class uuafbw_widget extends WP_Widget {

	const VERSION = '1.1.1';

	/**
	 * Constructor.
	 */
	public function __construct() {
		$args = array(
			'classname'   => 'uuafbw_widget',
			'description' => esc_html__( 'Displays featured content with an image, title, description and link.', 'uuatheme' ),
		);

		parent::__construct(
			'uuafbw_widget',
			esc_html__( 'UUA Feature Box', 'uuatheme' ),
			$args
		);

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
	}

	/**
	 * Loads the required scripts and styles for the widget control.
	 *
	 * @param string $hook The current admin page.
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( 'widgets.php' == $hook ) {
			$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

			wp_enqueue_media();
			wp_enqueue_script( 'uuatheme-media-upload', get_template_directory_uri() . '/assets/js/admin/uuatheme-media-upload' . $suffix . '.js', array( 'jquery', 'media-upload', 'media-views' ), self::VERSION );

			wp_localize_script( 'uuatheme-media-upload', 'uua_media_upload_params', array(
				'frame_title'  => __( 'Add Image', 'uuatheme' ),
				'button_title' => __( 'Add to Widget', 'uuatheme' ),
			) );
		}
	}

	/**
	 * Output widget.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args     Arguments.
	 * @param array $instance Widget instance.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		// Open link wrapper
		if ( ! empty( $instance['link_url'] ) ) {
			echo '<a href="' . esc_url( $instance['link_url'] ) . '">';
		}

		// Set image URL
		$image = '';
		if ( ! empty( $instance['image'] ) ) {
			$image = $instance['image'];
		}

		// Set description text
		$desc = '';
		if ( ! empty( $instance['description'] ) ) {
			$desc = esc_html( $instance['description'] );
		}

		// Featured content
		echo
			'<div class="thumbnail">',
				'<div class="box image">';

					// Image
					if ( ! empty( $image ) ) {
						echo '<img src="' . esc_url( $image ) . '" alt="' . esc_attr( $instance['title'] ) . '" class="img-responsive">';
					}

		echo
				'</div>',
				'<div class="caption">',

					// Content
					// $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'],
					'<h4>' . apply_filters( 'widget_title', $instance['title'] ) . '</h4>',
					wpautop( $desc );

					// Link title / button
					if ( ! empty( $instance['link_url'] ) && ! empty( $instance['link_title'] ) ) {
						echo '<p class="box-link">' . esc_html( $instance['link_title'] ) . '</p>';
					}
		echo
				'</div>',
			'</div>';

		// Close link wrapper
		if ( ! empty( $instance['link_url'] ) ) {
			echo '</a>';
		}

		echo $args['after_widget'];
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title']       = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['description'] = ( ! empty( $new_instance['description'] ) ) ? sanitize_textarea_field( $new_instance['description'] ) : '';
		$instance['link_url']    = ( ! empty( $new_instance['link_url'] ) ) ? sanitize_text_field( $new_instance['link_url'] ) : '';
		$instance['link_title']  = ( ! empty( $new_instance['link_title'] ) ) ? sanitize_text_field( $new_instance['link_title'] ) : '';
		$instance['image']       = ( ! empty( $new_instance['image'] ) ) ? sanitize_text_field( $new_instance['image'] ) : '';

		return $instance;
	}

	/**
	 * Outputs the settings update form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Instance.
	 */
	public function form( $instance ) {
		$title      = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$desc       = ! empty( $instance['description'] ) ? $instance['description'] : '';
		$link_url   = ! empty( $instance['link_url'] ) ? $instance['link_url'] : '';
		$link_title = ! empty( $instance['link_title'] ) ? $instance['link_title'] : __( 'Learn more', 'uuatheme' );
		$image      = ! empty( $instance['image'] ) ? $instance['image'] : '';
		?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title', 'uuatheme' ); ?>:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php _e( 'Description', 'uuatheme' ); ?>:</label>
			<textarea class="widefat" id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" type="text" ><?php echo esc_html( $desc ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link_url' ); ?>"><?php _e( 'Link URL', 'uuatheme' ); ?>:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_url' ); ?>" name="<?php echo $this->get_field_name( 'link_url' ); ?>" type="text" value="<?php echo esc_url( $link_url ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link_title' ); ?>"><?php _e( 'Link Title', 'uuatheme' ); ?>:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_title' ); ?>" name="<?php echo $this->get_field_name( 'link_title' ); ?>" type="text" value="<?php echo esc_attr( $link_title ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'image' ); ?>"><?php _e('Image', 'uuatheme'); ?>:</label><br>
			<input class="widefat" id="<?php echo $this->get_field_id( 'image' ); ?>" name="<?php echo $this->get_field_name( 'image' ); ?>" type="text" value="<?php echo esc_url( $image ); ?>" />
		</p>
		<p class="uua-widget-buttons media-widget-buttons">
			<label for="<?php echo $this->get_field_id( 'image' ); ?>">
				<input type="button" class="button select-media" value="<?php _ex( 'Add Image', 'label for button in the UUA Featured widget' ); ?>"  data-field_id="<?php echo $this->get_field_id( 'image' ); ?>" />
				<label for="<?php echo $this->get_field_id( 'image' ); ?>"><span class="description"><?php _e( 'Enter URL or upload image', 'uuatheme' ) ?></span></label>
			</label>
		</p>

<?php
	}
}
