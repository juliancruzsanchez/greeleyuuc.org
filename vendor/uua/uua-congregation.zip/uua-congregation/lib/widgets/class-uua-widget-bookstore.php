<?php
/**
 * UUA Bookstore Widget.
 *
 * @package uuatheme/Widgets
 * @version 2.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Widget UUA bookstore class.
 */
class uuais_widget extends WP_Widget {

	const VERSION = '2.0.0';

	/**
	 * Constructor.
	 */
	public function __construct() {
		$args = array(
			'classname'   => 'uuais_widget',
			'description' => esc_html__( 'Displays a featured UUA Bookstore item from a selected category.', 'uuatheme' ),
		);

		parent::__construct(
			'uuais_widget',
			esc_html__( 'UUA Bookstore', 'uuatheme' ),
			$args
		);
	}

	/**
	 * Retrieve bookstore data.
	 *
	 * @since 2.0.0
	 * @param string $type  Type of data to retrieve. Default is 'general'.
	 *                      Accepts: 'general', 'family', or 'social-justice'.
	 */
	private function retrieve_data( $type = 'general' ) {
		$endpoint = 'https://secure.uua.org/theme-support/';

		$response = wp_remote_request(
			esc_url_raw( $endpoint . $type )
		);

		$response = json_decode( wp_remote_retrieve_body( $response ) );

		return $response;
	}

	/**
	 * Output widget.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args     Arguments.
	 * @param array $instance Widget instance.
	 */
	public function widget( $args, $instance ) {
		$book = null;

		// Set list type
		switch ( $instance['select'] ) {
			case 'family':
				$type = 'family';
				break;
			case 'socialjustice':
				$type = 'social-justice';
				break;
			default:
				$type = 'general';
		}

		// Request bookstore data
		$books = $this->retrieve_data( $type );

		// Bail if no response
		if ( ! is_array( $books ) ) {
			return;
		}

		// Select random book data
		$book = $books[ array_rand( $books ) ];

		echo $args['before_widget'];

		// HTML output
		echo '<div class="uuais-entry">';

			// Open link wrapper
			if ( ! empty( $book->link ) ) {
				echo '<a href="' . esc_url( $book->link ) . '">';
			}

				// Image
				if ( ! empty( $book->image ) ) {
					// Notice: third-party image includes cross-site cookie
					echo '<img src="' . esc_url( $book->image ) . '" class="uuais-img" referrerpolicy="no-referrer">';
				}

				// Title
				if ( ! empty( $book->title ) ) {
					$subtitle = '';
					if ( ! empty( $book->subtitle ) ) {
						$subtitle = '<br /><small>' . esc_html( $book->subtitle ) . '</small>';
					}
					echo '<h4 style="margin-top:0;">' . esc_html( $book->title ) . $subtitle . '</h4>';
				}

			// Close link wrapper
			if ( ! empty( $book->link ) ) {
				echo '</a>';
			}

			// Metadata
			echo '<p class="uuais-meta">';

				// Author
				if ( ! empty( $book->author ) ) {
					echo '<span class="uuais_author">' . esc_html( $book->author ) . '</span>';
				}

				// Year
				if ( ! empty( $book->date ) ) {
					echo '<span class="uuais-year">, ' . esc_html( $book->date ) . '</span>';
				}

				// Publisher
				if ( ! empty( $book->publisher ) ) {
					echo '<br /><span class="uuais-publisher">' . esc_html( $book->publisher ) . '</span>';
				}

			echo '</p>';

			// Description
			$description = null;
			if ( ! empty( $description ) ) {
				echo '<p class="uuais_description" style="margin:0; font-size:90%;">' . esc_html( $description ) . '</p>';
			}

			// Footer
			if ( ! empty( $book->link ) ) {
				$logo = '<img src="' . get_template_directory_uri() . '/assets/images/logo-inspirit.png" alt="' . __( 'inSpirit: The UU Book and Gift Shop', 'uuatheme' ) . '">';
				echo
					'<div class="uuais-footer">',
						'<a href="' . esc_url( $book->link ) . '" class="uuais-buynow">' . sprintf( __( 'Buy it now at %s', 'uuatheme' ), $logo ) . '</a>',
					'</div>';
			}

		echo '</div>'; // .uuais-entry

		echo $args['after_widget'];
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['select'] = $new_instance['select'];
		return $instance;
	}

	/**
	 * Outputs the settings update form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Instance.
	 */
	public function form( $instance ) { ?>

		<p>
			<label for="<?php echo $this->get_field_id('select'); ?>"><?php _e( 'List Type', 'uuatheme' ); ?></label>
			<select id="<?php echo $this->get_field_id('select'); ?>" name="<?php echo $this->get_field_name('select'); ?>" class="widefat">
				<option <?php selected( $instance['select'], 'general'); ?> value="general"><?php _e( 'UU General', 'uuatheme' ); ?></option>
				<option <?php selected( $instance['select'], 'family'); ?> value="family"><?php _e( 'Family', 'uuatheme' ); ?></option>
				<option <?php selected( $instance['select'], 'socialjustice'); ?> value="socialjustice"><?php _e( 'Social Justice', 'uuatheme' ); ?></option>
			</select>
		</p>

<?php
	}
}
