<?php
/**
 * UUA Widget Functions
 *
 * Widget related functions and widget registration.
 *
 * @package uuatheme/Functions
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

// Include widget classes.
require_once 'class-uua-widget-bookstore.php';
require_once 'class-uua-widget-feature-box.php';

/**
 * Register Widgets.
 *
 * @since 1.2.0
 */
function uuatheme_register_widgets() {
	register_widget( 'uuais_widget' );
	register_widget( 'uuafbw_widget' );
}
add_action( 'widgets_init', 'uuatheme_register_widgets' );
