<?php
/**
 * UUA Congregation Admin
 *
 * @package uuatheme
 * @version 1.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * uuatheme_admin class.
 */
class uuatheme_admin {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_head', array( $this, 'admin_inline_styles' ) );
		add_action( 'edit_form_after_editor', array( $this, 'front_page_editor' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'block_editor_assets' ) );
	}

	/**
	 * Enqueue scripts for the block editor.
	 * @since WP 5.0
	 */
	public function block_editor_assets() {
		// only add script to front page editor
		if ( 'page' === get_post_type() && get_the_ID() == get_option( 'page_on_front' ) ) {
			wp_enqueue_script( 'uuatheme-script-blocks', get_theme_file_uri( '/assets/js/admin/block-editor.js' ), array( 'wp-blocks', 'wp-i18n', 'wp-notices' ) );
		}
	}

	/**
	 * Add inline CSS in the admin head with the style tag.
	 */
	public function admin_inline_styles() {
		echo
		'<style>',
			'.uuatheme-frontpage-editor { text-align: center; padding: 2em; margin-top: 20px; }',
			'.uuatheme-frontpage-editor .button { margin-bottom: 1em; }',
		'</style>';
	}

	/**
	 * Remove the content editor from the Front Page as all content is handled
	 * through Widgets.
	 *
	 * @param WP_Post $post Post object.
	 */
	public function front_page_editor( $post ) {

		// Bail if not using the 'Home Page' template
		if ( 'template-home.php' != basename( get_page_template() ) ) {
			return;
		}

		// Display link to customizer widgets
		echo
		'<div class="postbox uuatheme-frontpage-editor">',
			'<a href="' . esc_url( admin_url( 'customize.php?autofocus[panel]=widgets' ) ) . '" class="button button-primary button-hero">' . __( 'Customize Homepage', 'uuatheme' ) . '</a>',
			'<p>' . __( 'The homepage is made up of eight widget areas managed under Appearance › Widgets.', 'uuatheme' ) . '</p>',
		'</div>';
	}

}

return new uuatheme_admin();
