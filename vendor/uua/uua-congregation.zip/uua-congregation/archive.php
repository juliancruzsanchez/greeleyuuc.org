<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package uuatheme
 * @version 1.1
 */

get_header(); ?>

	<div class="primary-content col-md-7 col-md-push-2">
		<main id="main" class="main" role="main">

		<?php
		if ( have_posts() ) :

			/* Get the archive page title and description */
			the_archive_title( '<h1 class="page-title">', '</h1>' );
			the_archive_description( '<div class="taxonomy-description">', '</div>' );

			/* Start the Loop */
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'partials/content', get_post_format() );

			endwhile;

			if ( $wp_query->max_num_pages > 1 ) : ?>
				<nav class="post-nav">
					<ul class="pager">
						<li class="previous"><?php next_posts_link( __( '&larr; Older posts', 'uuatheme' ) ); ?></li>
						<li class="next"><?php previous_posts_link( __( 'Newer posts &rarr;', 'uuatheme' ) ); ?></li>
					</ul>
				</nav>
			<?php endif; ?>

		<?php else : ?>

			<div class="alert alert-warning">
				<?php _e( 'Sorry, no results were found.', 'uuatheme' ); ?>
			</div>
			<?php get_search_form(); ?>

		<?php endif; ?>

		</main><!-- #main -->
	</div><!-- .primary-content -->

	<?php get_sidebar('left'); ?>

	<?php get_sidebar(); ?>

<?php get_footer(); ?>
