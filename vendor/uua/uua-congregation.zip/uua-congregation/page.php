<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-page
 *
 * @package uuatheme
 * @version 1.1
 */

get_header(); ?>

	<div class="primary-content col-md-7 col-md-push-2">
		<main id="main" class="main" role="main">

			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'partials/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>

		</main><!-- #main -->
	</div><!-- .primary-content -->

	<?php get_sidebar('left'); ?>

	<?php get_sidebar(); ?>

<?php get_footer(); ?>
