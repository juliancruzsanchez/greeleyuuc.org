<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package uuatheme
 * @version 1.1
 */

get_header(); ?>

	<div class="primary-content col-md-9">
		<main id="main" class="main" role="main">
			<div class="page-header">
				<h2 class="page-title"><?php _e( 'Page Not Found', 'uuatheme' ); ?></h2>
			</div>

			<div class="alert alert-warning">
				<?php _e( 'Sorry, but the page you were trying to view does not exist.', 'uuatheme' ); ?>
			</div>

			<p><?php _e( 'It looks like this was the result of either:', 'uuatheme' ); ?></p>
			<ul style="margin-bottom:2em">
				<li><?php _e( 'a mistyped address', 'uuatheme' ); ?></li>
				<li><?php _e( 'an out-of-date link', 'uuatheme' ); ?></li>
			</ul>

			<?php get_search_form(); ?>

		</main><!-- #main -->
	</div><!-- .primary-content -->

	<?php get_sidebar(); ?>

<?php get_footer(); ?>
