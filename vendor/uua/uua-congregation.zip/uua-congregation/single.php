<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package uuatheme
 * @version 1.1
 */

get_header(); ?>

	<div class="primary-content col-md-7 col-md-push-2">
		<main id="main" class="main" role="main">

			<?php
			/* Start the Loop */
			while ( have_posts() ) : the_post();

				get_template_part( 'partials/content', 'single' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>

		</main><!-- #main -->
	</div><!-- .primary-content -->

	<?php get_sidebar('left'); ?>

	<?php get_sidebar(); ?>

<?php get_footer(); ?>
