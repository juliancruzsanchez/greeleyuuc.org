( function( wp ) {

	// Front page notice
	wp.data.dispatch('core/notices').createNotice(
		'warning', // Can be one of: success, info, warning, error.
		wp.i18n.__( 'The homepage is made up of eight widget areas managed under Appearance › Widgets.', 'uuatheme' ), // Text string to display.
		{
			id: 'uuatheme_customize_homepage',
			isDismissible: false, // Whether the user can dismiss the notice.
			// Any actions the user can perform.
			actions: [
				{
					url: 'customize.php?autofocus[panel]=widgets',
					label: wp.i18n.__( 'Customize Homepage', 'uuatheme' ) + ' ›'
				}
			]
		}
	);
} )( window.wp );
