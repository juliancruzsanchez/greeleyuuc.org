/*global uua_media_upload_params */
jQuery( function( $ ) {

	$(document).on('click', '.uua-widget-buttons .select-media', function(e) {
		var field_id = $(this).attr('data-field_id');

		var frame = wp.media({
			title : uua_media_upload_params.frame_title,
			multiple : false,
			library : { type : 'image' },
			button : { text : uua_media_upload_params.button_title }
		});

		// Handle results from media manager.
		frame.on('close',function( ) {
			var attachments = frame.state().get('selection').toJSON();
			var $image_url  = $( document.getElementById( field_id ) );

			// update the url if it has changed
			if ( $image_url.val() !== attachments[0].url ) {
				$image_url.val( attachments[0].url ).trigger( 'change' );
			}
		});

		frame.open();
		return false;
	});

});
