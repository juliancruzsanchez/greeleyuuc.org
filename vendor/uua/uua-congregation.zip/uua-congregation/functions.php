<?php
/**
 * UUA Congregation functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package uuatheme
 * @version 1.4.0
 */

/** Theme version */
function uuatheme_version() {
	$uuatheme = wp_get_theme( 'uua-congregation' );
	return $uuatheme->get( 'Version' );
}

/**
 * Check for theme updates.
 *
 * This will periodically send data to Kernl to check for security
 * and feature updates, and verify the validity of your license.
 */
include_once 'inc/kernl/kernl-update-checker.php';
if ( class_exists( 'Puc_v4_Factory' ) ) {
	$uuatheme_updater = Puc_v4_Factory::buildUpdateChecker(
		'https://kernl.us/api/v1/theme-updates/5a3b08a9b9705f1e9fa06fab/',
		__FILE__,
		'uua-congregation'
	);
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function uuatheme_setup() {
	/*
	 * Make theme available for translation.
	 */
	load_theme_textdomain( 'uuatheme', get_template_directory() . '/lang' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	add_image_size( 'medium', 420, 9999 );

	// Set the default content width.
	$GLOBALS['content_width'] = 1140;

	// This theme uses wp_nav_menu() in four locations.
	register_nav_menus( array(
		'primary_navigation' => __( 'Primary Navigation', 'uuatheme' ),
		'utility_navigation' => __( 'Utility Navigation', 'uuatheme' ),
		'footer_navigation'  => __( 'Footer Navigation', 'uuatheme' ),
		'page_navigation'    => __( 'Page Navigation', 'uuatheme' ),
	) );

	// Enable support for Custom Backgrounds.
	add_theme_support( 'custom-background' );

	// Enable support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Enable support for Jetpack Testimonials
	add_theme_support( 'jetpack-testimonial' );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, and column width.
	 */
	add_editor_style( 'assets/css/editor-style.css' );
}
add_action( 'after_setup_theme', 'uuatheme_setup' );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function uuatheme_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Primary', 'uuatheme' ),
		'id'            => 'sidebar-primary',
		'description'   => __( 'Add widgets here to appear in your right sidebar.', 'uuatheme' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Secondary', 'uuatheme' ),
		'id'            => 'sidebar-secondary',
		'description'   => __( 'Add widgets here to appear after the Primary sidebar widgets.', 'uuatheme' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Left Sidebar', 'uuatheme' ),
		'id'            => 'sidebar-left',
		'description'   => __( 'Add widgets here to appear in your left sidebar.', 'uuatheme' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '',
		'after_title'   => '',
	) );

	register_sidebar( array(
		'name'          => __( 'Home 1', 'uuatheme' ),
		'id'            => 'sidebar-home-one',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Home 2', 'uuatheme' ),
		'id'            => 'sidebar-home-two',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Home 3', 'uuatheme' ),
		'id'            => 'sidebar-home-three',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Home 4', 'uuatheme' ),
		'id'            => 'sidebar-home-four',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Home 5', 'uuatheme' ),
		'id'            => 'sidebar-home-five',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Home 6', 'uuatheme' ),
		'id'            => 'sidebar-home-six',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Home 7', 'uuatheme' ),
		'id'            => 'sidebar-home-seven',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Home 8', 'uuatheme' ),
		'id'            => 'sidebar-home-eight',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 1', 'uuatheme' ),
		'id'            => 'sidebar-footer-one',
		'description'   => __( 'Add widgets here to appear in your footer.', 'uuatheme' ),
		'before_widget' => '<section id="%1$s" class="widget col-md-3 %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 2', 'uuatheme' ),
		'id'            => 'sidebar-footer-two',
		'description'   => __( 'Add widgets here to appear in your footer.', 'uuatheme' ),
		'before_widget' => '<section id="%1$s" class="widget col-md-3 %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 3', 'uuatheme' ),
		'id'            => 'sidebar-footer-three',
		'description'   => __( 'Add widgets here to appear in your footer.', 'uuatheme' ),
		'before_widget' => '<section id="%1$s" class="widget col-md-3 %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'uuatheme_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function uuatheme_scripts() {
	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(), '4.7.0' );

	// Theme stylesheet.
	wp_enqueue_style( 'uuatheme-style', get_stylesheet_uri(), array(), uuatheme_version() );

	// Theme scripts.
	wp_enqueue_script( 'uuatheme-script', get_theme_file_uri( '/assets/js/scripts.js' ), array( 'jquery' ), uuatheme_version(), true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'uuatheme_scripts' );

/**
 * Enable Shortcodes in Widgets.
 */
add_filter( 'widget_text', 'do_shortcode' );

/**
 * Allow HTML in Category descriptions.
 */
remove_filter( 'pre_term_description', 'wp_filter_kses' );

/**
 * Disable wpautop() from the text widget.
 */
remove_filter( 'widget_text_content', 'wpautop' );

/**
 * Theme Includes
 */
locate_template( 'lib/customizer.php', true );                             // Theme customizer options
locate_template( 'lib/tgmpa.php', true );                                  // Required and recommended plugins
locate_template( 'lib/nav.php', true );                                    // Custom nav modifications
locate_template( 'lib/template-tags.php', true );                          // Custom template tags
locate_template( 'lib/template-functions.php', true );                     // Additional features
locate_template( 'lib/shortcodes/uua-shortcode-map.php', true );           // Shortcodes: Google Maps
locate_template( 'lib/shortcodes/uua-shortcode-staffer.php', true );       // Shortcodes: Staffer
locate_template( 'lib/shortcodes/uua-shortcode-testimonials.php', true );  // Shortcodes: Testimonials
locate_template( 'lib/widgets/uua-widget-functions.php', true );           // Widgets

if ( is_admin() ) {
	locate_template( 'lib/class-uua-admin.php', true );
}
