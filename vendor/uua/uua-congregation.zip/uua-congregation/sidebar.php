<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package uuatheme
 * @version 1.1
 */
?>

<aside class="col-md-3 right-sidebar" role="complementary">

	<?php dynamic_sidebar('sidebar-primary'); ?>

	<?php dynamic_sidebar('sidebar-secondary'); ?>

</aside>
