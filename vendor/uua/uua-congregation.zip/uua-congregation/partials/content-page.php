<?php
/**
 * Template part for displaying page content
 *
 * @package uuatheme
 * @version 1.1
 */
?>

<div class="page-header">
	<h1><?php the_title(); ?></h1>
</div>

<?php the_content(); ?>

<?php wp_link_pages( array( 'before' => '<nav class="pagination">', 'after' => '</nav>' ) ); ?>
