<?php
/**
 * Template part for post entry meta
 *
 * @package uuatheme
 * @version 1.1
 */
?>
<div class="entrymeta">
	<time datetime="<?php echo get_the_date( DATE_W3C ); ?>"><?php echo get_the_date(); ?></time>
	<?php
	if ( 'uu_services' === get_post_type() ) {
		echo get_the_term_list(
			get_the_ID(),
			'uu_service_speaker',
			'<span class="speaker">',
			', ',
			'</span>'
		);
	} else {
		$author_link = get_the_author_posts_link();
		if ( ! empty( $author_link ) ) {
			echo '&bull; <span class="post-author">' . $author_link . '</span>';
		}
	}
	?>

</div>
