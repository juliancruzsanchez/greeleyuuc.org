<?php
/**
 * Displays social media links
 *
 * @package uuatheme
 * @version 1.1
 */

$social_links = array(
	'facebook'   => get_theme_mod('uuatheme_facebook_link'),
	'twitter'    => get_theme_mod('uuatheme_twitter_link'),
	'youtube'    => get_theme_mod('uuatheme_youtube_link'),
	'pinterest'  => get_theme_mod('uuatheme_pinterest_link'),
	'instagram'  => get_theme_mod('uuatheme_instagram_link'),
	'googleplus' => get_theme_mod('uuatheme_googleplus_link'),
);

echo '<div class="social-media-links">';

if ( $social_links['facebook'] ) {
	echo '<a href="' . esc_url( $social_links['facebook'] ) . '"><i class="fa fa-facebook-official fa-2x"></i><span class="sr-only">' . __( 'Facebook', 'uuatheme' ) . '</span></a> ';
}

if ( $social_links['twitter'] ) {
	echo '<a href="' . esc_url( $social_links['twitter'] ) . '"><i class="fa fa-twitter fa-2x"></i><span class="sr-only">' . __( 'Twitter', 'uuatheme' ) . '</span></a> ';
}

if ( $social_links['youtube'] ) {
	echo '<a href="' . esc_url( $social_links['youtube'] ) . '"><i class="fa fa-youtube fa-2x"></i><span class="sr-only">' . __( 'YouTube', 'uuatheme' ) . '</span></a> ';
}

if ( $social_links['pinterest'] ) {
	echo '<a href="' . esc_url( $social_links['pinterest'] ) . '"><i class="fa fa-pinterest fa-2x"></i><span class="sr-only">' . __( 'Pinterest', 'uuatheme' ) . '</span></a> ';
}

if ( $social_links['instagram'] ) {
	echo '<a href="' . esc_url( $social_links['instagram'] ) . '"><i class="fa fa-instagram fa-2x"></i><span class="sr-only">' . __( 'Instagram', 'uuatheme' ) . '</span></a> ';
}

if ( $social_links['googleplus'] ) {
	echo '<a href="' . esc_url( $social_links['googleplus'] ) . '"><i class="fa fa-google-plus fa-2x"></i><span class="sr-only">' . __( 'GooglePlus', 'uuatheme' ) . '</span></a> ';
}

echo '</div>';
?>
