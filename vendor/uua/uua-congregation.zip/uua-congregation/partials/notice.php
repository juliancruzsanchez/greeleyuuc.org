<?php
/**
 * Sitewide Notice
 *
 * Displays a sitewide notice above the header.
 *
 * @package uuatheme
 * @version 1.0
 */

if ( true == get_theme_mod( 'uuatheme_notice_enabled', false ) ) : ?>

<div class="site-notice">
	<div class="container">

		<?php echo uuatheme_get_notice_content(); ?>

	</div>
</div>

<?php endif; ?>
