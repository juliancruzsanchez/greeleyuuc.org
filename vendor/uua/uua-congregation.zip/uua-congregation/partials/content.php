<?php
/**
 * Template part for displaying posts
 *
 * @package uuatheme
 * @version 1.1
 */
?>

<article <?php post_class(); ?>>
	<header>
		<h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<?php get_template_part( 'partials/entry-meta' ); ?>

	</header>
	<div class="entry-summary">
		<?php the_excerpt(); ?>
	</div>
</article>
