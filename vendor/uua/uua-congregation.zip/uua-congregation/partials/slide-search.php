<?php
/**
 * Site Search
 *
 * Displays a search bar above the header when the "Search" link is clicked.
 *
 * @link https://www.uua.org/communications/websites/wordpress-theme/documentation/configuration/header
 *
 * @package uuatheme
 * @version 1.1
 */
?>

<div class="row slide-search">
	<div class="container">
		<div class="sitesearch">
			<?php get_search_form(); ?>

		</div>
	</div>
</div>
