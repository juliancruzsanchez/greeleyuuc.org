<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package uuatheme
 * @version 1.1
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<section id="comments" class="comments">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$comments_number = get_comments_number();
			$comments_title = '<span>' . get_the_title() . '</span>';
			if ( '1' === $comments_number ) {
				/* translators: %s: post title */
				printf( _x( 'One Response to &ldquo;%s&rdquo;', 'comments title', 'uuatheme' ), $comments_title );
			} else {
				printf(
					/* translators: 1: number of comments, 2: post title */
					_nx(
						'%1$s Response to &ldquo;%2$s&rdquo;',
						'%1$s Responses to &ldquo;%2$s&rdquo;',
						$comments_number,
						'comments title',
						'uuatheme'
					),
					number_format_i18n( $comments_number ),
					$comments_title
				);
			}
			?>
		</h2>

		<ol class="comment-list">
			<?php
				wp_list_comments( array(
					'style'       => 'ol',
					'short_ping'  => true,
				) );
			?>
		</ol>

		<?php the_comments_pagination( array(
			'prev_text' => __( '&larr; Older comments', 'uuatheme' ),
			'next_text' => __( 'Newer comments &rarr;', 'uuatheme' ),
		) );

	endif; // Check for have_comments().

	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>

		<div class="alert alert-warning">
			<p class="no-comments"><?php _e( 'Comments are closed.', 'uuatheme' ); ?></p>
		</div>
	<?php
	endif;

	comment_form();
	?>

</section><!-- #comments -->
