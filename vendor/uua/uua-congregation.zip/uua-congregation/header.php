<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div class="content row">
 *
 * @package uuatheme
 * @version 1.3
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="skip"><a href="#content"><?php _e( 'Skip to content', 'uuatheme' ); ?></a></div>

<?php get_template_part( 'partials/notice' ); ?>

<?php get_template_part( 'partials/slide', 'search' ); ?>

<?php get_template_part( 'partials/slide', 'location' ); ?>

<div class="row masthead-header">
	<div class="container">
		<div class="col-md-7 logo-area">
			<a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url('/') ); ?>">
				<?php
					$logo = get_theme_mod('uuatheme_logo_upload');
					if ( $logo ) {
						if ( is_ssl() ) {
							$logo = str_replace( 'http://', 'https://', $logo );
						}
						echo '<img src="' . esc_url( $logo ) . '" alt="' . get_bloginfo( 'name' ) .'">';
					} else {
						echo '<img src="' . get_template_directory_uri() . '/assets/images/uuachalice_gradient.png' . '" alt="UUA Logo" class="default-logo">';
					}
				?>

				<div class="site-title" <?php echo ( $logo ) ? 'style="text-indent:-9999px"' : ''; ?>>
					<h1><?php bloginfo( 'name' ); ?></h1>
					<?php
						$description = get_bloginfo( 'description' );
						if ( ! empty( $description ) ) {
							echo '<span class="site-description">' . esc_html( $description ) . '</span>';
						}
					?>
				</div>
			</a>
		</div>
		<div class="col-md-5 header-right">

			<?php get_template_part( 'partials/social-media-icons' ); ?>

			<?php
			// Utility navigation
			if ( has_nav_menu( 'utility_navigation' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'utility_navigation',
					'menu_class' => 'nav nav-pills',
					)
				);
			}
			?>

			<div class="header-text-field"><?php echo uuatheme_get_header_text(); ?></div>
		</div>
	</div>
</div>

<header class="banner navbar navbar-default navbar-static-top" role="banner">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only"><?php _e( 'Toggle navigation', 'uuatheme' ); ?></span>
				<span><?php _e( 'Menu', 'uuatheme' ); ?> <i class="fa fa-angle-down"></i></span>
			</button>
		</div>
		<nav class="collapse navbar-collapse" role="navigation">
			<span class="sr-only"><?php _e( 'Main Navigation', 'uuatheme' ); ?></span>
			<?php
			// Primary navigation
			if ( has_nav_menu( 'primary_navigation' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'primary_navigation',
					'menu_class' => 'nav navbar-nav',
					'walker' => new wp_bootstrap_navwalker(),
					)
				);
			}
			?>
		</nav>
	</div>
</header>

<div id="content" class="wrap" tabindex="0" role="document">
	<div class="container">
		<div class="content row">

		<?php
		// Site breadcrumbs
		if ( ! is_front_page() && function_exists('yoast_breadcrumb') ) {
			yoast_breadcrumb( '<div class="col-md-12"><p id="breadcrumbs">', '</p></div>' );
		}
		?>
