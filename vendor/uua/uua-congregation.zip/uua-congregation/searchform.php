<?php
/**
 * Template for displaying search forms
 *
 * @package uuatheme
 * @version 1.1
 */

$unique_id = esc_attr( uniqid( 'search-form-' ) );
?>

<form role="search" method="get" class="search-form form-inline" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="sr-only" for="<?php echo $unique_id; ?>">
		<span><?php echo _x( 'Search for:', 'label', 'uuatheme' ); ?></span>
	</label>
	<div class="input-group">
		<input type="search" id="<?php echo $unique_id; ?>" class="search-field form-control" placeholder="<?php echo esc_attr_x( 'Search &hellip;', 'placeholder', 'uuatheme' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
		<span class="input-group-btn">
			<button type="submit" class="search-submit btn btn-default"><?php echo _x( 'Search', 'submit button', 'uuatheme' ); ?></button>
		</span>
	</div>
</form>
