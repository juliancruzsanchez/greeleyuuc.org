<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package uuatheme
 * @version 1.1
 */

get_header(); ?>

	<div class="primary-content col-md-12">
		<main id="main" class="main" role="main">
			<div class="page-header">
				<h2 class="page-title"><?php printf( __( 'Search Results for: %s', 'uuatheme' ), get_search_query() ); ?></h2>
			</div>

			<?php
			if ( have_posts() ) :

				/* Start the Loop */
				while ( have_posts() ) : the_post();

					/**
					 * Run the loop for the search to output the results.
					 * If you want to overload this in a child theme then include a file
					 * called content-search.php and that will be used instead.
					 */
					get_template_part( 'partials/content', get_post_format() );

				endwhile;

				if ( $wp_query->max_num_pages > 1 ) : ?>
					<nav class="post-nav">
						<ul class="pager">
							<li class="previous"><?php next_posts_link( __( '&larr; Older posts', 'uuatheme' ) ); ?></li>
							<li class="next"><?php previous_posts_link( __( 'Newer posts &rarr;', 'uuatheme' ) ); ?></li>
						</ul>
					</nav>
				<?php endif; ?>

			<?php else : ?>

				<div class="alert alert-warning">
					<?php _e( 'Sorry, no results were found.', 'uuatheme' ); ?>
				</div>
				<?php get_search_form(); ?>

			<?php endif; ?>

		</main><!-- #main -->
	</div><!-- .primary-content -->

<?php get_footer(); ?>
