<?php
/**
 * Template Name: Full-Width Page (no sidebars)
 *
 * @package uuatheme
 * @version 1.1
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="main col-md-12" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'partials/content', 'page' ); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
				?>

			<?php endwhile; // End of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>
