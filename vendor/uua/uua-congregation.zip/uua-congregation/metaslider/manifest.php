<?php
/**
 * UUA MetaSlider Theme
 */
return array(
	'uua' => array(
		'folder' => 'uua',
		'title' => 'UUA Slider',
		'supports' => array( 'flex', 'responsive', 'nivo', 'coin' ),
		'description' => __( 'A unique theme built specifically for the UUA Theme.', 'uuatheme' ),
		'screenshot_dir' => get_template_directory_uri() . '/metaslider/uua',
	)
);
