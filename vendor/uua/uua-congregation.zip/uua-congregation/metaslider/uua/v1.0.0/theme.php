<?php

defined( 'ABSPATH' ) || exit;

/**
 * Main theme file
 */
class MetaSlider_Theme_UUA extends MetaSlider_Theme_Base {
	/**
	 * Theme ID
	 *
	 * @var string
	 */
	public $id = 'uua';

	/**
	 * Theme Version
	 *
	 * @var string
	 */
	public $version = '1.0.0';

	public function __construct() {
		parent::__construct( $this->id, $this->version );
	}

	/**
	 * Parameters
	 *
	 * @var string
	 */
	public $slider_parameters = array(
		'height'   => 400,
		'delay'    => 4000,
		'effect'   => '"slide"',
		'prevText' => '\'<svg aria-hidden="true" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M31.7 239l136-136c9.4-9.4 24.6-9.4 33.9 0l22.6 22.6c9.4 9.4 9.4 24.6 0 33.9L127.9 256l96.4 96.4c9.4 9.4 9.4 24.6 0 33.9L201.7 409c-9.4 9.4-24.6 9.4-33.9 0l-136-136c-9.5-9.4-9.5-24.6-.1-34z"></path></svg>\'',
		'nextText' => '\'<svg aria-hidden="true" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg>\'',
	);

	/**
	 * Enqueues theme specific styles and scripts
	 */
	public function enqueue_assets() {
		wp_enqueue_style( 'metaslider_uua_theme_styles', get_template_directory_uri() . '/metaslider/' . $this->id . '/v1.0.0/style.css', array( 'metaslider-public' ), '1.0.0' );
	}
}

if (!isset(MetaSlider_Theme_Base::$themes['uua'])) new MetaSlider_Theme_UUA();
