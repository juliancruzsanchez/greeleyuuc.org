UUA Congregation Theme for WordPress
====================

The UUA Congregation WordPress theme is a framework for your own congregational website.

* Documentation: [UUA Congregation Theme](https://www.uua.org/communications/websites/wordpress-theme)
* Comments or Questions: [UUA Website Forum](https://www.uua.org/communications/websites/forum)

- - -

# Shortcodes

The theme comes with several shortcodes that can be used to insert content inside posts and pages.

* **[uuatheme_map]** – shows a google map of the specified address.
* **[uua_staffer]** – shows a list of staff profiles from the [Staffer](https://wordpress.org/plugins/staffer/) plugin.
* **[uua_testimonials]** – shows a list of testimonials from the [Testimonials by WooThemes](https://wordpress.org/plugins/testimonials-by-woothemes/) plugin.

## Map Shortcode

Display a Google Map of the address entered. You will need to add your [Google API Key](https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key) to the _Customizer_ › _Congregation Map_ settings for more advanced options, otherwise it defaults to the free iframe embedded map.

`[uuatheme_map address="6300 A Street, Lincoln, NE 68510"]`


### Attributes

The following parameters are accepted:

| Attribute            | Default       | Description
| -------------------- | ------------- | ----------------------------------------------------
| `address`            | `null`        | (Required) Specify the address for the map.
| `width`              | `100%`        | The width of the embedded map.
| `height`             | `400px`       | The height of the embedded map.


Advanced parameters accepted when using a [Google API Key](https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key):

| Attribute            | Default       | Description
| -------------------- | ------------- | ----------------------------------------------------
| `label`              | `empty`       | Adds a text label to the map marker.
| `enablescrollwheel`  | `true`        | Enables the user to navigate the map based on mouse scroll wheel.
| `disablecontrols`    | `false`       | Disables all of the map controls.
| `zoom`               | `15`          | The initial resolution/scale at which to display the map. Range: 0 to 20

- - -

# Widgets

Two widgets come with the theme that help you display your content in the widgetized areas.

* **UUA Feature Box** - Display featured content with an image, title, description and link.
* **UUA Bookstore** - Display a featured UUA Bookstore item from a selected category.

- - -

# Recommended Plugins

Below is a list of recommended plugins that compliment the UUA Congregation Theme with additional functionality.

## UUA Services Plugin

The theme comes bundled with the [UUA Services plugin](https://www.uua.org/communications/websites/wordpress-theme/documentation/technical/services-plugin) to include service management (Sunday morning or other services) within the site.

## WordPress Plugin Repository

* [Custom Sidebars](https://wordpress.org/plugins/custom-sidebars/)
* [Events Manager](https://wordpress.org/plugins/events-manager/)
* [Jetpack](https://wordpress.org/plugins/jetpack/)
* [List Category Posts](https://wordpress.org/plugins/list-category-posts/)
* [MetaSlider](https://wordpress.org/plugins/ml-slider/)
* [Site Origin Widgets Bundle](https://wordpress.org/plugins/so-widgets-bundle/)
* [Staffer](https://wordpress.org/plugins/staffer/)
* [WordPress SEO by Yoast](https://wordpress.org/plugins/wordpress-seo/)
